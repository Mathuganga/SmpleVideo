import { Component, OnInit } from '@angular/core';
import * as yt from 'ionic-youtube-streams';
import { StreamingMedia, StreamingVideoOptions } from '@ionic-native/streaming-media/ngx';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: [ './details.page.scss' ],
})
export class DetailsPage implements OnInit {
  pageName: any
  overall: any;
  constructor(public streamingMedia: StreamingMedia,
    public activatedRoute: ActivatedRoute) { }
  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.pageName = params[ 'title' ];
      this.overall = params[ 'overall' ];
    });
  }

  async streamVideo() {
    let passurl = ''
    if (this.overall === 'Maths') {
      passurl = 'N0_TWQTrJ-k'
    }
    else if (this.overall === 'Science') {
      passurl = 'QYTMsxc0hZM'

    }
    else if (this.overall === 'English') {
      passurl = 'IhQt_fxGOcw'

    }
    else if (this.overall === 'Social Science') {
      passurl = '8exHvk7mals'

    }
    else if (this.overall === 'language') {
      passurl = 'Kz64czn1JcQ'
    }
    else {
      passurl = 'ukLnPbIffxE'

    }
    const info: any = await yt.info(passurl);
    this.streamURL(info.formats[ 0 ].url);
  }

  private streamURL(url: any) {
    const options: StreamingVideoOptions = {
      successCallback: () => {
      },
      errorCallback: (e) => {
        console.log('Error streaming');
      },
      orientation: 'portrait',
      shouldAutoClose: true,
      controls: true
    };

    this.streamingMedia.playVideo(url, options);
  }

}

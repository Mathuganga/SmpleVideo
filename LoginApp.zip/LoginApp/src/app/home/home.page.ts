import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: [ 'home.page.scss' ],
})
export class HomePage {
  tappeditemindex: any = false;
  tappeditemindexflag: any;
  SubjectList = [
    {
      name: 'Maths',
      Chapters: [
        {
          chaptername: ' Maths Chapter 1'
        },
        {
          chaptername: ' Maths Chapter 2'
        },
        {
          chaptername: ' Maths Chapter 3'
        },
        {
          chaptername: ' Maths Chapter 4'
        },
        {
          chaptername: ' Maths Chapter 5'
        },
      ]
    },
    {
      name: 'Science',
      Chapters: [
        {
          chaptername: ' Science Chapter 1'
        },
        {
          chaptername: ' Science Chapter 2'
        },
        {
          chaptername: ' Science Chapter 3'
        },
        {
          chaptername: ' Science Chapter 4'
        },
        {
          chaptername: 'Science Chapter 5'
        },
      ]
    },
    {
      name: 'English',
      Chapters: [
        {
          chaptername: ' English Chapter 1'
        },
        {
          chaptername: ' English Chapter 2'
        },
        {
          chaptername: ' English Chapter 3'
        },
        {
          chaptername: ' English Chapter 4'
        },
        {
          chaptername: 'English Chapter  5'
        },
      ]
    },
    {
      name: 'Social Science',
      Chapters: [
        {
          chaptername: '  Social Science Chapter 1'
        },
        {
          chaptername: ' Social  Science Chapter 2'
        },
        {
          chaptername: ' Social Science Chapter 3'
        },
        {
          chaptername: ' Social Science Chapter 4'
        },
        {
          chaptername: ' Social Science Chapter 5'
        },
      ]
    },
    {
      name: 'language',
      Chapters: [
        {
          chaptername: ' language Chapter 1'
        },
        {
          chaptername: ' language Chapter 2'
        },
        {
          chaptername: ' language Chapter 3'
        },
        {
          chaptername: ' language Chapter 4'
        },
        {
          chaptername: 'language Chapter 5'
        },
      ]
    }
  ]
  overall: any;
  constructor(

    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  tappeditem(i, overall) {
    if (i !== this.tappeditemindex) {
      this.tappeditemindex = i;
      this.tappeditemindexflag = true
    }
    else {
      this.tappeditemindexflag = !this.tappeditemindexflag
    }
    this.overall = overall;

  }

  gotoDetails(item) {
    console.log(item)
    this.router.navigate(
      [
        'details',
        {

          title: item.chaptername,
          overall: this.overall
        },
      ],
      { relativeTo: this.activatedRoute }
    );
  }
}


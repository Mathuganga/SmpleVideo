import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { StreamingMedia, StreamingVideoOptions } from '@ionic-native/streaming-media/ngx';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from './common.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: [ 'home.page.scss' ],
})
export class HomePage {
  selectedTabIndex = "personal";
  submitjson = {
    title: '',
    email: '',
    phone: '',
    location: '',
  }
  loginForm: FormGroup;
  defaultform: FormGroup;
  error_messages = {
    'email': [ {
      type: 'required',
      message: 'email is required.'
    },
    {
      type: 'minlength',
      message: 'email length.'
    },
    {
      type: 'maxlength',
      message: 'email length.'
    },
    {
      type: 'pattern',
      message: 'Invalid Email'
    }
    ],

    'currentpassword': [ {
      type: 'required',
      message: 'password is required.'
    },
    {
      type: 'minlength',
      message: 'password length.'
    },
    {
      type: 'maxlength',
      message: 'password length.'
    }
    ],
  }
  tappeditemindex: any = false;
  tappeditemindexflag: any;


  constructor(public alertController: AlertController,
    public formBuilder: FormBuilder,
    private streamingMedia: StreamingMedia,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private common: CommonService

  ) {
    this.defaultform = this.formBuilder.group({

      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      currentpassword: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(16)
      ])),
    },

    )
  }
  segmentChanged(ev: any) {

  }
  async SaveChanges() {
    console.log('alert getting called', this.defaultform.value);
    this.router.navigate(
      [
        'chapters',
      ],
      { relativeTo: this.activatedRoute }
    );
  }

  password(formGroup: FormGroup) {
    const { value: password } = formGroup.get('password');
    const { value: confirmPassword } = formGroup.get('confirmpassword');
    return password === confirmPassword ? null : { passwordNotMatch: true };
  }
  tappeditem(i) {
    this.tappeditemindex = i;
  }
}
